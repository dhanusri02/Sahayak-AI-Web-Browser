/**
 * Sahayak - Content Script (content.js)
 * Injected into every page at document_idle.
 * Listens for messages from the side panel and returns page content / selected text.
 */

(function () {
  'use strict';

  /**
   * Extract clean page text, capped at 12,000 chars (head + tail preserved).
   * Strips script/style content automatically via innerText.
   */
  function getPageText() {
    try {
      const raw = (document.body && document.body.innerText) ? document.body.innerText : '';
      const cleaned = raw.replace(/\s{3,}/g, '\n\n').trim();
      const MAX = 12000;
      if (cleaned.length <= MAX) return cleaned;
      // Preserve head (8000) + tail (4000) with separator
      return cleaned.slice(0, 8000) + '\n\n[...content truncated...]\n\n' + cleaned.slice(-4000);
    } catch (e) {
      return '';
    }
  }

  /**
   * Get text currently selected by the user, trimmed.
   */
  function getSelectedText() {
    try {
      return (window.getSelection() || '').toString().trim();
    } catch (e) {
      return '';
    }
  }

  // Listen for messages from the side panel
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message && message.command === 'page/getContent') {
      const pageText    = getPageText();
      const selectedText = getSelectedText();

      sendResponse({
        title:        document.title || '',
        url:          window.location.href || '',
        text:         pageText,
        selectedText: selectedText
      });

      return true; // keep message channel open for async sendResponse
    }
  });
})();

